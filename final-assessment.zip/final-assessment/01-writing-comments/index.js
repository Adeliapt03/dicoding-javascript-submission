//ni_putu_adelia_candra_swari_Gojf

/*
Goal tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer.
*/